//
//  RecordSoundsViewController.swift
//  PitchPerfect
//
//  Created by Feras Azzam on 1/2/19.
//  Copyright © 2019 Syriail. All rights reserved.
//

import UIKit

// import AVFoundation which contains AVAudioRecorder
import AVFoundation

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {

    @IBOutlet weak var stopRecordingButton: UIButton!
    @IBOutlet weak var recordingButton: UIButton!
    @IBOutlet weak var recordingLabel: UILabel!
    // to use and reference the AudioRecorder in multiple places (when we start recording and when we stop recording
    var audioRecorder: AVAudioRecorder!
    
    // stopRecordingButtion should be disabled when running the app
    override func viewDidLoad() {
        super.viewDidLoad()
       
       stopRecordingButton.isEnabled = false
       
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func recordingButtonAction(_ sender: Any) {
        
        // change the text of the recordingLabel to recording in process after clicking on the recordingButton
        recordingLabel.text = "Recording in process"
        // disable the recordingButton
        recordingButton.isEnabled = false
        // active the stopRecordingButton
        stopRecordingButton.isEnabled = true
       
        // setup the path of the recorded file
       let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))
        // we use the sharedInstance because we have only one hardware to record audio
        let session = AVAudioSession.sharedInstance()
        // setup the session for playing and recording audio
        try! session.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.default, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
        // creat the audioRecorder and start recording
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
        
    }
    
    @IBAction func stopRecordingButtonAction(_ sender: Any) {
        // setup recordingLabel back to tap to record
        recordingLabel.text = "tap to record"
        // active the recordingButton
        recordingButton.isEnabled = true
        // disable the stopRecordingButton
        stopRecordingButton.isEnabled = false
        // stop the recording
        audioRecorder.stop()
        // deactivate the sharedInstance
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag
        {
        performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)
        }
        else
        {
            print("recording was not successful")
        }
        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "stopRecording"
        {
            let playSoundsVR = segue.destination as! PlaySoundsViewController
            let recordedAudioURL = sender as! URL
            playSoundsVR.recordedAudioURL = recordedAudioURL
        }
    }
    
}

